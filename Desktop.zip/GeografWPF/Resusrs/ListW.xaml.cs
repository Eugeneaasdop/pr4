﻿using GeografWPF.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;

namespace GeografWPF.Resusrs
{
    /// <summary>
    /// Логика взаимодействия для ListW.xaml
    /// </summary>
    public partial class ListW : Page
    {
        public ListW()
        {
            InitializeComponent();
            var currentUser = GeografyEntities1.GetContext().Country.ToList();
            LViewCountry.ItemsSource = currentUser;
            DataContext = LViewCountry;
            CmbFiltr.Items.Add("Все Страны");
            foreach (var item in GeografyEntities1.GetContext().Country.
                Select(x => x.Name).Distinct().ToList())
                CmbFiltr.Items.Add(item);
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            Class.ClassFrame.frmObj.Navigate(new Addcon((sender as System.Windows.Controls.Button).DataContext as Country));
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string search = TxtSearch.Text;
            if (TxtSearch.Text != null)
            {
                LViewCountry.ItemsSource = GeografyEntities1.GetContext().Country.
                    Where(x => x.Name.Contains(search)
                    || x.Name.Contains(search)
                    || x.Capital.Contains(search)
                    || x.Square.ToString().Contains(search)).ToList();
            }
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            LViewCountry.ItemsSource = GeografyEntities1.GetContext().Country.
               OrderBy(x => x.Name).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            LViewCountry.ItemsSource = GeografyEntities1.GetContext().Country.
               OrderByDescending(x => x.Name).ToList();
        }

        private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbFiltr.SelectedValue.ToString() == "Все Страны")
            {
                LViewCountry.ItemsSource = GeografyEntities1.GetContext().Country.ToList();
            }
            else
            {
                LViewCountry.ItemsSource = GeografyEntities1.GetContext().Country.
                    Where(x => x.Name == CmbFiltr.SelectedValue.ToString()).ToList();
            }
        }

        private void BtnSaveToExcel_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();
            Excel.Workbook wb = app.Workbooks.Add();
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexRows = 1;
            worksheet.Cells[1][indexRows] = "Номер";
            worksheet.Cells[2][indexRows] = "Страна";
            worksheet.Cells[3][indexRows] = "Столица";
            worksheet.Cells[4][indexRows] = "Площадь";
            var printItems = LViewCountry.Items;
            foreach (Country item in printItems)
            {
                worksheet.Cells[1][indexRows + 1] = indexRows;
                worksheet.Cells[2][indexRows + 1] = item.Name;
                worksheet.Cells[3][indexRows + 1] = item.Capital;
                worksheet.Cells[4][indexRows + 1] = item.Square;
                indexRows++;
            }
            Excel.Range range = worksheet.Range[worksheet.Cells[2][indexRows + 1],
                    worksheet.Cells[4][indexRows + 1]];
            range.ColumnWidth = 30; 
            range.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            app.Visible = true;
        }
    }
}
